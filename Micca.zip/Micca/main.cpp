#include "define/stdafx.h"
#include "api/xor.h"
#include "api/api.h"
#include "driver/driver.h"
#include "inject/injector.h"
#include "api/drvutils.h"


//Names: Fortnite/Valorant - UnrealWindow, Apex - Respawn001, I'll find COD later
int main()
{
	// driver init
	start_driver();
	cout << endl;
						//Game					//Name of your dll *has to be named this*
	face_injecor_v2(xor_a("UnrealWindow"), xor_w(L"Micca.dll")); 

	cout << endl;
	system("pause");
}